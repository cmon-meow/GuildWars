//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GWDatBrowser.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_GWDATBROWSER_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDD_PREVIEW                     129
#define IDR_MENU1                       130
#define IDR_CONTEXT                     130
#define IDI_ICON1                       133
#define IDC_LOG                         1001
#define IDC_LIST1                       1002
#define IDC_CUSTOM1                     1006
#define IDC_DUMMY                       1006
#define IDC_PROGRESS1                   1007
#define IDC_FILESREAD                   1008
#define IDC_SLIDER1                     1010
#define IDC_BUTTON1                     1011
#define IDC_BUTTON2                     1012
#define IDC_BUTTON3                     1013
#define IDC_CHECK1                      1014
#define IDC_TIME                        1016
#define IDC_INFO                        1017
#define ID_IMAGE_BACKGROUND             32771
#define ID_BACKGROUND_BLACK             32772
#define ID_BACKGROUND_WHITE             32773
#define ID_BACKGROUND_CHECK             32774
#define ID_BACKGROUND_GREY              32775
#define ID_BACKGROUND_NONE              32776
#define ID_IMAGE_SAVEIMAGE              32777
#define ID_SAVEIMAGE_A                  32778
#define ID_IMAGE_EXPORTIMAGE            32779
#define ID_HEX_EXPORTRAWDATA            32780
#define ID_HEX_COLUMNS                  32781
#define ID_COLUMNS_SHOWADDRESS          32782
#define ID_COLUMNS_SHOWHEX              32783
#define ID_COLUMNS_SHOWDEC              32784
#define ID_COLUMNS_SHOWOCTAL            32785
#define ID_COLUMNS_SHOWBINARY           32786
#define ID_COLUMNS_SHOWASCII            32787
#define ID_COLUMNS_SHOWHEADER           32788
#define ID_HEX_HEADER                   32789
#define ID_HEADER_SHOWADDRESS           32790
#define ID_HEADER_SHOWHEX               32791
#define ID_HEADER_SHOWDECIMAL           32792
#define ID_HEADER_SHOWDINARY            32793
#define ID_HEADER_SHOWBINARY            32794
#define ID_HEADER_SHOWOCTAL             32795
#define ID_HEADER_SHOWASCII             32796
#define ID_FILELIST_EXPORTIMAGE         32797
#define ID_FILELIST_EXPORTRAWDATA       32798
#define ID_SOUND_EXPORTSOUND            32799

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32800
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
